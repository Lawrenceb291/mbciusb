# CampusFlix - Campus Movie Rental System

## Overview

CampusFlix is a comprehensive web application designed for campus-based movie rental services. It provides a Netflix-like interface for students to browse and rent movies via USB stick pickup from smart lockers. The system supports both entertainment and educational content, with an admin panel for inventory management and booking oversight.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **Styling**: TailwindCSS with Shadcn/ui component library
- **State Management**: TanStack Query (React Query) for server state
- **Build Tool**: Vite for development and bundling
- **Theme**: Custom cinema-themed design with dark color palette

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ESM modules
- **API Pattern**: RESTful API endpoints under `/api/` prefix
- **Development**: Hot module replacement via Vite middleware integration
- **Error Handling**: Centralized error middleware with structured responses

### Database Design
- **ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL (configured for Neon serverless)
- **Migrations**: Drizzle Kit for schema management
- **Schema Location**: Shared schema definitions in `/shared/schema.ts`

## Key Components

### Data Models
1. **Users**: Basic authentication system with username/password
2. **Movies**: Comprehensive movie catalog with metadata (title, genre, category, rating, poster, availability)
3. **Bookings**: Rental management with pickup codes, locker locations, and rental duration tracking

### Core Features
- **Movie Catalog**: Browse, search, and filter movies by genre and category
- **Booking System**: Reserve movies with pickup scheduling and locker assignment
- **Admin Dashboard**: Movie management, booking oversight, and inventory tracking
- **Responsive Design**: Mobile-first approach with adaptive layouts

### User Interface Components
- **Movie Cards**: Visual movie representation with availability status
- **Booking Modal**: Streamlined rental process with form validation
- **Admin Tables**: Data management interfaces for movies and bookings
- **Search/Filter**: Real-time movie discovery functionality

## Data Flow

### Movie Browsing Flow
1. Client requests movies from `/api/movies` with optional filters
2. Server queries database using Drizzle ORM
3. Movies returned with availability status and metadata
4. Frontend renders movie cards with real-time availability

### Booking Process Flow
1. Student selects movie and fills booking form
2. System generates unique pickup code
3. Booking record created with locker assignment
4. Confirmation sent with pickup details
5. Movie availability decremented

### Admin Management Flow
1. Admin views comprehensive dashboard with metrics
2. CRUD operations on movies and bookings
3. Real-time inventory tracking
4. Booking status management (upcoming, active, returned, overdue)

## External Dependencies

### Core Libraries
- **@tanstack/react-query**: Server state management and caching
- **drizzle-orm**: Type-safe database operations
- **@neondatabase/serverless**: PostgreSQL serverless connection
- **wouter**: Lightweight React routing
- **zod**: Runtime type validation and schema parsing

### UI Framework
- **@radix-ui/***: Headless UI primitives for accessibility
- **tailwindcss**: Utility-first CSS framework
- **shadcn/ui**: Pre-built component library
- **lucide-react**: Icon library

### Development Tools
- **vite**: Build tool and development server
- **tsx**: TypeScript execution for development
- **esbuild**: Production bundling for server code

## Deployment Strategy

### Development Environment
- **Hot Reload**: Vite development server with Express middleware
- **Database**: Neon PostgreSQL with connection pooling
- **Port Configuration**: Application runs on port 5000
- **Module System**: Full ESM support across frontend and backend

### Production Build
- **Frontend**: Vite builds to `dist/public` directory
- **Backend**: esbuild compiles server to `dist/index.js`
- **Static Serving**: Express serves built frontend assets
- **Environment**: NODE_ENV-based configuration switching

### Database Management
- **Schema Sync**: `npm run db:push` for development schema updates
- **Migration**: Drizzle Kit handles schema versioning
- **Connection**: Environment variable-based database URL configuration

### Platform Integration
- **Replit**: Native support with cartographer and error overlay plugins
- **Autoscale**: Configured for automatic scaling deployment
- **Process Management**: Parallel workflow support for development and production
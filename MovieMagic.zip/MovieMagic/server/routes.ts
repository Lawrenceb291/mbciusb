import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'penguin.greetings2023@gmail.com',
    pass: process.env.EMAIL_PASSWORD
  }
});

import { insertMovieSchema, insertBookingSchema } from "@shared/schema";
import { z } from "zod";

const AUTHORIZED_ADMIN_EMAILS = [
  "admin@university.edu",
  "librarian@university.edu"
];

function isAuthorizedAdmin(email: string): boolean {
  return AUTHORIZED_ADMIN_EMAILS.includes(email.toLowerCase());
}

// Generate a random 12-character password
const generatePassword = () => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  return Array.from(crypto.getRandomValues(new Uint8Array(12)))
    .map(x => chars[x % chars.length])
    .join('');
};

const ADMIN_PASSWORD = generatePassword();
console.log('Generated Admin Password:', ADMIN_PASSWORD); // This will show in server logs

function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const userEmail = req.headers['x-user-email'];
  const password = req.headers['x-admin-password'];
  
  if (!userEmail || !isAuthorizedAdmin(userEmail as string)) {
    return res.status(403).json({ message: "Unauthorized access" });
  }

  if (!password || password !== ADMIN_PASSWORD) {
    return res.status(403).json({ message: "Invalid admin password" });
  }
  
  next();
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Add redirect handler for mbcimovies.ca
  app.use((req, res, next) => {
    const host = req.headers.host?.toLowerCase();
    if (host === 'mbcimovies.ca') {
      return res.redirect(301, `https://${process.env.REPL_SLUG}.repl.co${req.url}`);
    }
    next();
  });
  // Movies routes
  app.get("/api/movies", async (req, res) => {
    try {
      const { search, genre, category } = req.query;
      const movies = await storage.searchMovies(
        search as string || "",
        genre as string,
        category as string
      );
      res.json(movies);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch movies" });
    }
  });

  app.get("/api/movies/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const movie = await storage.getMovie(id);
      
      if (!movie) {
        return res.status(404).json({ message: "Movie not found" });
      }
      
      res.json(movie);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch movie" });
    }
  });

  app.post("/api/movies", async (req, res) => {
    try {
      const movieData = insertMovieSchema.parse(req.body);
      const movie = await storage.createMovie(movieData);
      res.status(201).json(movie);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid movie data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create movie" });
    }
  });

  app.put("/api/movies/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const movieData = insertMovieSchema.partial().parse(req.body);
      const movie = await storage.updateMovie(id, movieData);
      
      if (!movie) {
        return res.status(404).json({ message: "Movie not found" });
      }
      
      res.json(movie);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid movie data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update movie" });
    }
  });

  app.delete("/api/movies/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteMovie(id);
      
      if (!success) {
        return res.status(404).json({ message: "Movie not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete movie" });
    }
  });

  // Bookings routes
  app.get("/api/bookings", async (req, res) => {
    try {
      const { studentEmail } = req.query;
      
      if (studentEmail) {
        const bookings = await storage.getBookingsByStudent(studentEmail as string);
        return res.json(bookings);
      }
      
      const bookings = await storage.getAllBookings();
      res.json(bookings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bookings" });
    }
  });

  app.get("/api/bookings/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const booking = await storage.getBooking(id);
      
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      res.json(booking);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch booking" });
    }
  });

  app.post("/api/bookings", async (req, res) => {
    try {
      const bookingData = insertBookingSchema.parse(req.body);
      
      // Check if movie exists and has available copies
      const movie = await storage.getMovie(bookingData.movieId);
      if (!movie) {
        return res.status(404).json({ message: "Movie not found" });
      }
      
      if (movie.availableCopies <= 0) {
        return res.status(400).json({ message: "Movie is not available for rental" });
      }
      
      const booking = await storage.createBooking(bookingData);
      res.status(201).json(booking);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid booking data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create booking" });
    }
  });

  app.put("/api/bookings/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const bookingData = insertBookingSchema.partial().parse(req.body);
      const booking = await storage.updateBooking(id, bookingData);
      
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      res.json(booking);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid booking data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update booking" });
    }
  });

  app.post("/api/notify", async (req, res) => {
    try {
      const { to, subject, body } = req.body;
      await transporter.sendMail({
        from: 'your-email@gmail.com', // Replace with your email
        to,
        subject,
        text: body
      });
      res.status(200).json({ message: "Email sent successfully" });
    } catch (error) {
      console.error('Email error:', error);
      res.status(500).json({ message: "Failed to send email" });
    }
  });

  app.delete("/api/bookings/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteBooking(id);
      
      if (!success) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete booking" });
    }
  });

  // Return movie (mark as returned)
  app.post("/api/bookings/:id/return", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const booking = await storage.getBooking(id);
      
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      // Update booking status and return date
      const updatedBooking = await storage.updateBooking(id, { 
        status: "returned" 
      });
      
      if (updatedBooking) {
        // Increase available copies
        const movie = await storage.getMovie(booking.movieId);
        if (movie) {
          await storage.updateMovie(booking.movieId, {
            availableCopies: movie.availableCopies + 1
          });
        }
      }
      
      res.json(updatedBooking);
    } catch (error) {
      res.status(500).json({ message: "Failed to return movie" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

import { users, movies, bookings, type User, type InsertUser, type Movie, type InsertMovie, type Booking, type InsertBooking } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Movies
  getAllMovies(): Promise<Movie[]>;
  getMovie(id: number): Promise<Movie | undefined>;
  createMovie(movie: InsertMovie): Promise<Movie>;
  updateMovie(id: number, movie: Partial<InsertMovie>): Promise<Movie | undefined>;
  deleteMovie(id: number): Promise<boolean>;
  searchMovies(query: string, genre?: string, category?: string): Promise<Movie[]>;
  
  // Bookings
  getAllBookings(): Promise<(Booking & { movie: Movie })[]>;
  getBooking(id: number): Promise<(Booking & { movie: Movie }) | undefined>;
  getBookingsByStudent(studentEmail: string): Promise<(Booking & { movie: Movie })[]>;
  createBooking(booking: InsertBooking): Promise<Booking>;
  updateBooking(id: number, booking: Partial<InsertBooking>): Promise<Booking | undefined>;
  deleteBooking(id: number): Promise<boolean>;
  generatePickupCode(): string;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private movies: Map<number, Movie>;
  private bookings: Map<number, Booking>;
  private currentUserId: number;
  private currentMovieId: number;
  private currentBookingId: number;

  constructor() {
    this.users = new Map();
    this.movies = new Map();
    this.bookings = new Map();
    this.currentUserId = 1;
    this.currentMovieId = 1;
    this.currentBookingId = 1;
    
    // Initialize with some sample movies
    this.initializeSampleMovies();
  }

  private initializeSampleMovies() {
    const sampleMovies: InsertMovie[] = [
      {
        title: "Quantum Pursuit",
        description: "An elite agent races against time to prevent a quantum weapon from falling into wrong hands.",
        genre: "Action",
        category: "entertainment",
        duration: "2h 15m",
        year: 2023,
        rating: "8.7",
        posterUrl: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600",
        availableCopies: 3,
        totalCopies: 3,
      },
      {
        title: "Campus Hearts",
        description: "A hilarious journey of college romance and friendship that will keep you laughing.",
        genre: "Comedy",
        category: "entertainment",
        duration: "1h 45m",
        year: 2023,
        rating: "7.9",
        posterUrl: "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600",
        availableCopies: 2,
        totalCopies: 2,
      },
      {
        title: "Neural Network",
        description: "In a world where minds can be connected, one programmer discovers a dangerous conspiracy.",
        genre: "Sci-Fi",
        category: "entertainment",
        duration: "2h 30m",
        year: 2024,
        rating: "9.1",
        posterUrl: "https://images.unsplash.com/photo-1485846234645-a62644f84728?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600",
        availableCopies: 2,
        totalCopies: 3,
      },
      {
        title: "Ocean Depths",
        description: "Explore the mysteries of deep ocean life and marine ecosystems.",
        genre: "Documentary",
        category: "educational",
        duration: "1h 30m",
        year: 2023,
        rating: "8.5",
        posterUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600",
        availableCopies: 4,
        totalCopies: 4,
      },
      {
        title: "Tech Revolution",
        description: "A comprehensive look at how technology is reshaping our world and future possibilities.",
        genre: "Documentary",
        category: "educational",
        duration: "1h 25m",
        year: 2024,
        rating: "8.2",
        posterUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600",
        availableCopies: 3,
        totalCopies: 3,
      },
      {
        title: "Study Smart",
        description: "Essential study techniques and methods for academic success in higher education.",
        genre: "Educational",
        category: "study-resources",
        duration: "2h 0m",
        year: 2024,
        rating: "8.8",
        posterUrl: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600",
        availableCopies: 5,
        totalCopies: 5,
      },
      {
        title: "Midnight Shadows",
        description: "A supernatural thriller that will keep you on the edge of your seat.",
        genre: "Horror",
        category: "entertainment",
        duration: "1h 55m",
        year: 2023,
        rating: "7.6",
        posterUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600",
        availableCopies: 0,
        totalCopies: 2,
      },
      {
        title: "Mountain Quest",
        description: "An epic adventure through treacherous mountain terrain and self-discovery.",
        genre: "Adventure",
        category: "entertainment",
        duration: "2h 5m",
        year: 2024,
        rating: "8.3",
        posterUrl: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600",
        availableCopies: 1,
        totalCopies: 2,
      }
    ];

    sampleMovies.forEach(movie => {
      const id = this.currentMovieId++;
      this.movies.set(id, { ...movie, id });
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAllMovies(): Promise<Movie[]> {
    return Array.from(this.movies.values());
  }

  async getMovie(id: number): Promise<Movie | undefined> {
    return this.movies.get(id);
  }

  async createMovie(movie: InsertMovie): Promise<Movie> {
    const id = this.currentMovieId++;
    const newMovie: Movie = { ...movie, id };
    this.movies.set(id, newMovie);
    return newMovie;
  }

  async updateMovie(id: number, movieUpdate: Partial<InsertMovie>): Promise<Movie | undefined> {
    const existingMovie = this.movies.get(id);
    if (!existingMovie) return undefined;
    
    const updatedMovie = { ...existingMovie, ...movieUpdate };
    this.movies.set(id, updatedMovie);
    return updatedMovie;
  }

  async deleteMovie(id: number): Promise<boolean> {
    return this.movies.delete(id);
  }

  async searchMovies(query: string, genre?: string, category?: string): Promise<Movie[]> {
    const allMovies = Array.from(this.movies.values());
    
    return allMovies.filter(movie => {
      const matchesQuery = !query || 
        movie.title.toLowerCase().includes(query.toLowerCase()) ||
        movie.description.toLowerCase().includes(query.toLowerCase());
      
      const matchesGenre = !genre || genre === "All Genres" || movie.genre === genre;
      const matchesCategory = !category || category === "All Categories" || movie.category === category;
      
      return matchesQuery && matchesGenre && matchesCategory;
    });
  }

  async getAllBookings(): Promise<(Booking & { movie: Movie })[]> {
    const allBookings = Array.from(this.bookings.values());
    const result = [];
    
    for (const booking of allBookings) {
      const movie = this.movies.get(booking.movieId);
      if (movie) {
        result.push({ ...booking, movie });
      }
    }
    
    return result;
  }

  async getBooking(id: number): Promise<(Booking & { movie: Movie }) | undefined> {
    const booking = this.bookings.get(id);
    if (!booking) return undefined;
    
    const movie = this.movies.get(booking.movieId);
    if (!movie) return undefined;
    
    return { ...booking, movie };
  }

  async getBookingsByStudent(studentEmail: string): Promise<(Booking & { movie: Movie })[]> {
    const allBookings = Array.from(this.bookings.values()).filter(
      booking => booking.studentEmail === studentEmail
    );
    
    const result = [];
    for (const booking of allBookings) {
      const movie = this.movies.get(booking.movieId);
      if (movie) {
        result.push({ ...booking, movie });
      }
    }
    
    return result.sort((a, b) => 
      new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
    );
  }

  async createBooking(booking: InsertBooking): Promise<Booking> {
    const id = this.currentBookingId++;
    const pickupCode = this.generatePickupCode();
    const newBooking: Booking = { 
      ...booking, 
      id, 
      pickupCode,
      createdAt: new Date(),
      returnedAt: null
    };
    
    this.bookings.set(id, newBooking);
    
    // Decrease available copies
    const movie = this.movies.get(booking.movieId);
    if (movie && movie.availableCopies > 0) {
      movie.availableCopies--;
      this.movies.set(booking.movieId, movie);
    }
    
    return newBooking;
  }

  async updateBooking(id: number, bookingUpdate: Partial<InsertBooking>): Promise<Booking | undefined> {
    const existingBooking = this.bookings.get(id);
    if (!existingBooking) return undefined;
    
    const updatedBooking = { ...existingBooking, ...bookingUpdate };
    this.bookings.set(id, updatedBooking);
    return updatedBooking;
  }

  async deleteBooking(id: number): Promise<boolean> {
    const booking = this.bookings.get(id);
    if (booking) {
      // Increase available copies if booking is cancelled
      const movie = this.movies.get(booking.movieId);
      if (movie) {
        movie.availableCopies++;
        this.movies.set(booking.movieId, movie);
      }
    }
    return this.bookings.delete(id);
  }

  generatePickupCode(): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < 6; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    
    // Ensure code is unique
    const existingCodes = Array.from(this.bookings.values()).map(b => b.pickupCode);
    if (existingCodes.includes(result)) {
      return this.generatePickupCode();
    }
    
    return result;
  }
}

export const storage = new MemStorage();

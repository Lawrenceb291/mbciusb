import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const movies = pgTable("movies", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  genre: text("genre").notNull(),
  category: text("category").notNull(), // entertainment, educational, study-resources
  duration: text("duration").notNull(),
  year: integer("year").notNull(),
  rating: text("rating").notNull(),
  posterUrl: text("poster_url").notNull(),
  availableCopies: integer("available_copies").notNull().default(0),
  totalCopies: integer("total_copies").notNull().default(0),
});

export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  movieId: integer("movie_id").notNull(),
  studentName: text("student_name").notNull(),
  studentEmail: text("student_email").notNull(),
  pickupCode: text("pickup_code").notNull().unique(),
  pickupDate: text("pickup_date").notNull(),
  pickupTime: text("pickup_time").notNull(),
  lockerLocation: text("locker_location").notNull(),
  rentalDuration: integer("rental_duration").notNull(), // hours
  status: text("status").notNull().default("upcoming"), // upcoming, active, returned, overdue
  createdAt: timestamp("created_at").defaultNow(),
  returnedAt: timestamp("returned_at"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertMovieSchema = createInsertSchema(movies).omit({
  id: true,
});

export const insertBookingSchema = createInsertSchema(bookings).omit({
  id: true,
  pickupCode: true,
  createdAt: true,
  returnedAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertMovie = z.infer<typeof insertMovieSchema>;
export type Movie = typeof movies.$inferSelect;
export type InsertBooking = z.infer<typeof insertBookingSchema>;
export type Booking = typeof bookings.$inferSelect;

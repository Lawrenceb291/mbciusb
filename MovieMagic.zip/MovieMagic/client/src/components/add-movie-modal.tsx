import { useState } from "react";
import { insertMovieSchema } from "@shared/schema";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

interface AddMovieModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function AddMovieModal({ open, onOpenChange }: AddMovieModalProps) {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    genre: "",
    category: "",
    duration: "",
    year: new Date().getFullYear(),
    rating: "",
    posterUrl: "",
    totalCopies: 1,
  });
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createMovieMutation = useMutation({
    mutationFn: async (movieData: any) => {
      const response = await apiRequest("POST", "/api/movies", movieData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Movie Added",
        description: "The movie has been successfully added to the catalog.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/movies"] });
      onOpenChange(false);
      setFormData({
        title: "",
        description: "",
        genre: "",
        category: "",
        duration: "",
        year: new Date().getFullYear(),
        rating: "",
        posterUrl: "",
        totalCopies: 1,
      });
    },
    onError: () => {
      toast({
        title: "Failed to Add Movie",
        description: "There was an error adding the movie. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const validatedData = insertMovieSchema.parse({
        ...formData,
        availableCopies: formData.totalCopies,
      });

      createMovieMutation.mutate(validatedData);
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast({
          title: "Validation Error",
          description: error.errors[0].message,
          variant: "destructive",
        });
      }
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto cinema-nav">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-white">Add New Movie</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label className="text-gray-300">Movie Title</Label>
              <Input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="cinema-card border-gray-600 text-white"
                placeholder="Enter movie title"
                required
              />
            </div>
            
            <div>
              <Label className="text-gray-300">Genre</Label>
              <Select 
                value={formData.genre} 
                onValueChange={(value) => setFormData({ ...formData, genre: value })}
              >
                <SelectTrigger className="cinema-card border-gray-600 text-white">
                  <SelectValue placeholder="Select Genre" />
                </SelectTrigger>
                <SelectContent className="cinema-card border-gray-600">
                  <SelectItem value="Action">Action</SelectItem>
                  <SelectItem value="Comedy">Comedy</SelectItem>
                  <SelectItem value="Drama">Drama</SelectItem>
                  <SelectItem value="Horror">Horror</SelectItem>
                  <SelectItem value="Sci-Fi">Sci-Fi</SelectItem>
                  <SelectItem value="Documentary">Documentary</SelectItem>
                  <SelectItem value="Educational">Educational</SelectItem>
                  <SelectItem value="Adventure">Adventure</SelectItem>
                  <SelectItem value="Thriller">Thriller</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label className="text-gray-300">Duration</Label>
              <Input
                type="text"
                value={formData.duration}
                onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
                className="cinema-card border-gray-600 text-white"
                placeholder="e.g., 2h 15m"
                required
              />
            </div>
            
            <div>
              <Label className="text-gray-300">Year</Label>
              <Input
                type="number"
                value={formData.year}
                onChange={(e) => setFormData({ ...formData, year: parseInt(e.target.value) })}
                className="cinema-card border-gray-600 text-white"
                min="1900"
                max="2030"
                required
              />
            </div>
            
            <div>
              <Label className="text-gray-300">Rating</Label>
              <Input
                type="text"
                value={formData.rating}
                onChange={(e) => setFormData({ ...formData, rating: e.target.value })}
                className="cinema-card border-gray-600 text-white"
                placeholder="8.5"
                required
              />
            </div>
          </div>

          <div>
            <Label className="text-gray-300">Description</Label>
            <Textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="cinema-card border-gray-600 text-white"
              rows={4}
              placeholder="Enter movie description"
              required
            />
          </div>

          <div>
            <Label className="text-gray-300">Poster Image URL</Label>
            <Input
              type="url"
              value={formData.posterUrl}
              onChange={(e) => setFormData({ ...formData, posterUrl: e.target.value })}
              className="cinema-card border-gray-600 text-white"
              placeholder="https://images.unsplash.com/..."
              required
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label className="text-gray-300">Category</Label>
              <Select 
                value={formData.category} 
                onValueChange={(value) => setFormData({ ...formData, category: value })}
              >
                <SelectTrigger className="cinema-card border-gray-600 text-white">
                  <SelectValue placeholder="Select Category" />
                </SelectTrigger>
                <SelectContent className="cinema-card border-gray-600">
                  <SelectItem value="entertainment">Entertainment</SelectItem>
                  <SelectItem value="educational">Educational</SelectItem>
                  <SelectItem value="study-resources">Study Resources</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label className="text-gray-300">USB Copies Available</Label>
              <Input
                type="number"
                value={formData.totalCopies}
                onChange={(e) => setFormData({ ...formData, totalCopies: parseInt(e.target.value) })}
                className="cinema-card border-gray-600 text-white"
                min="1"
                max="20"
                required
              />
            </div>
          </div>

          <div className="flex gap-4 pt-6">
            <Button 
              type="button" 
              variant="outline"
              className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-700"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="flex-1 bg-cinema-red hover:bg-red-700 text-white font-semibold"
              disabled={createMovieMutation.isPending}
            >
              {createMovieMutation.isPending ? "Adding..." : "Add Movie"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

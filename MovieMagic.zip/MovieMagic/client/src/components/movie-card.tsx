import { Movie } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star } from "lucide-react";
import { getAvailabilityStatus } from "@/lib/utils";

interface MovieCardProps {
  movie: Movie;
  onBook: (movie: Movie) => void;
  size?: "small" | "large";
}

export default function MovieCard({ movie, onBook, size = "large" }: MovieCardProps) {
  const availability = getAvailabilityStatus(movie.availableCopies);
  
  if (size === "small") {
    return (
      <div 
        className="group cursor-pointer"
        onClick={() => onBook(movie)}
      >
        <div className="cinema-card rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 group-hover:scale-105">
          <div className="aspect-[2/3] relative overflow-hidden">
            <img 
              src={movie.posterUrl} 
              alt={`${movie.title} poster`} 
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" 
            />
            <div className="absolute top-2 right-2">
              <Badge className={`${availability.color} text-white px-2 py-1 text-xs font-semibold`}>
                {availability.label}
              </Badge>
            </div>
            {movie.category === "educational" && (
              <div className="absolute top-2 left-2">
                <Badge className="bg-blue-500 text-white px-2 py-1 text-xs font-semibold">
                  Educational
                </Badge>
              </div>
            )}
          </div>
          <div className="p-3">
            <h3 className="text-white font-semibold text-sm mb-1 truncate">{movie.title}</h3>
            <p className="text-gray-400 text-xs">{movie.genre} • {movie.duration}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div 
      className="group cursor-pointer"
      onClick={() => onBook(movie)}
    >
      <Card className="cinema-card rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 group-hover:scale-105">
        <div className="aspect-[2/3] relative overflow-hidden">
          <img 
            src={movie.posterUrl} 
            alt={`${movie.title} poster`} 
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" 
          />
          <div className="absolute top-3 right-3">
            <Badge className={`${availability.color} text-white px-2 py-1 text-xs font-semibold`}>
              {availability.label}
            </Badge>
          </div>
          {movie.category === "educational" && (
            <div className="absolute top-3 left-3">
              <Badge className="bg-blue-500 text-white px-2 py-1 text-xs font-semibold">
                Educational
              </Badge>
            </div>
          )}
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
            <h3 className="text-white font-bold text-lg mb-1">{movie.title}</h3>
            <p className="text-gray-300 text-sm">{movie.genre} • {movie.duration}</p>
          </div>
        </div>
        <div className="p-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center cinema-gold font-semibold">
              <Star className="w-4 h-4 mr-1 fill-current" />
              {movie.rating}
            </div>
            <span className="text-gray-400 text-sm">{movie.year}</span>
          </div>
          <p className="text-gray-300 text-sm mb-3 line-clamp-3">{movie.description}</p>
          <Button 
            className="w-full bg-cinema-red hover:bg-red-700 text-white font-semibold transition-colors"
            onClick={(e) => {
              e.stopPropagation();
              onBook(movie);
            }}
            disabled={movie.availableCopies === 0}
          >
            {movie.availableCopies === 0 ? "Not Available" : "Book Now"}
          </Button>
        </div>
      </Card>
    </div>
  );
}

import { useState } from "react";
import { Movie, insertBookingSchema } from "@shared/schema";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Star, MapPin } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

interface BookingModalProps {
  movie: Movie | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const bookingFormSchema = insertBookingSchema.extend({
  studentName: z.string().min(1, "Name is required"),
  studentEmail: z.string().email("Valid email is required"),
  pickupDate: z.string().min(1, "Pickup date is required"),
  pickupTime: z.string().min(1, "Pickup time is required"),
  lockerLocation: z.string().min(1, "Locker location is required"),
  rentalDuration: z.number().min(24, "Minimum rental duration is 24 hours"),
});

export default function BookingModal({ movie, open, onOpenChange }: BookingModalProps) {
  const [formData, setFormData] = useState({
    studentName: "",
    studentEmail: "",
    pickupDate: "",
    pickupTime: "",
    lockerLocation: "",
    rentalDuration: 24,
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createBookingMutation = useMutation({
    mutationFn: async (bookingData: any) => {
      const response = await apiRequest("POST", "/api/bookings", bookingData);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Booking Confirmed!",
        description: `Your pickup code is: ${data.pickupCode}`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/movies"] });
      queryClient.invalidateQueries({ queryKey: ["/api/bookings"] });
      onOpenChange(false);
      setFormData({
        studentName: "",
        studentEmail: "",
        pickupDate: "",
        pickupTime: "",
        lockerLocation: "",
        rentalDuration: 24,
      });
    },
    onError: () => {
      toast({
        title: "Booking Failed",
        description: "There was an error creating your booking. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!movie) return;

    try {
      const validatedData = bookingFormSchema.parse({
        ...formData,
        movieId: movie.id,
        status: "upcoming",
      });

      createBookingMutation.mutate(validatedData);
      
      // Send email notification
      await fetch('/api/notify', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          to: 'penguin.greetings2023@gmail.com',
          subject: 'New Movie Booking',
          body: `New booking details:\nMovie: ${movie.title}\nStudent: ${formData.studentName}\nEmail: ${formData.studentEmail}\nPickup Date: ${formData.pickupDate}\nPickup Time: ${formData.pickupTime}\nDelivery Location: ${formData.deliveryLocation || 'N/A'}`
        }),
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast({
          title: "Validation Error",
          description: error.errors[0].message,
          variant: "destructive",
        });
      }
    }
  };

  if (!movie) return null;

  const getTomorrowDate = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto cinema-nav">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-white">Book Movie</DialogTitle>
        </DialogHeader>

        <div className="text-gray-300 mb-4">
            Rental Price: <span className="text-cinema-gold">$2.00 per day</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Movie Info */}
          <div>
            <img 
              src={movie.posterUrl} 
              alt={`${movie.title} poster`} 
              className="w-full rounded-lg mb-4" 
            />
            <h3 className="text-xl font-bold text-white mb-2">{movie.title}</h3>
            <p className="text-gray-400 mb-4">{movie.description}</p>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-400">Genre:</span>
                <span className="text-white">{movie.genre}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Duration:</span>
                <span className="text-white">{movie.duration}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Rating:</span>
                <div className="flex items-center cinema-gold">
                  <Star className="w-4 h-4 mr-1 fill-current" />
                  {movie.rating}
                </div>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Available:</span>
                <span className="text-white">{movie.availableCopies} copies</span>
              </div>
            </div>
          </div>

          {/* Booking Form */}
          <div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label className="text-black font-semibold">Full Name</Label>
                <Input
                  type="text"
                  value={formData.studentName}
                  onChange={(e) => setFormData({ ...formData, studentName: e.target.value })}
                  className="cinema-card border-gray-600 text-black bg-white placeholder:text-gray-400"
                  placeholder="Enter your full name"
                  required
                />
              </div>

              <div>
                <Label className="text-black font-semibold">Email Address</Label>
                <Input
                  type="email"
                  value={formData.studentEmail}
                  onChange={(e) => setFormData({ ...formData, studentEmail: e.target.value })}
                  className="cinema-card border-gray-600 text-black bg-white placeholder:text-gray-400"
                  placeholder="Enter your email"
                  required
                />
              </div>

              <div>
                <Label className="text-black font-semibold">Pickup Date</Label>
                <Input
                  type="date"
                  value={formData.pickupDate}
                  onChange={(e) => setFormData({ ...formData, pickupDate: e.target.value })}
                  className="cinema-card border-gray-600 text-black bg-white"
                  min={getTomorrowDate()}
                  required
                />
              </div>

              <div>
                <Label className="text-black font-semibold">Pickup Time</Label>
                <Select 
                  value={formData.pickupTime} 
                  onValueChange={(value) => setFormData({ ...formData, pickupTime: value })}
                >
                  <SelectTrigger className="cinema-card border-gray-600 text-black bg-white">
                    <SelectValue placeholder="Select Time" />
                  </SelectTrigger>
                  <SelectContent className="cinema-card border-gray-600 text-black bg-white">
                    <SelectItem value="09:00">9:00 AM</SelectItem>
                    <SelectItem value="11:00">11:00 AM</SelectItem>
                    <SelectItem value="13:00">1:00 PM</SelectItem>
                    <SelectItem value="15:00">3:00 PM</SelectItem>
                    <SelectItem value="17:00">5:00 PM</SelectItem>
                    <SelectItem value="19:00">7:00 PM</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-black font-semibold">Delivery Method</Label>
                <Select 
                  value={formData.lockerLocation} 
                  onValueChange={(value) => setFormData({ ...formData, lockerLocation: value })}
                >
                  <SelectTrigger className="cinema-card border-gray-600 text-black bg-white">
                    <SelectValue placeholder="Select Delivery Method" />
                  </SelectTrigger>
                  <SelectContent className="cinema-card border-gray-600 text-black bg-white">
                    <SelectItem value="Direct Delivery">Direct Delivery</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {formData.lockerLocation === "Direct Delivery" && (
                <>
                  <div>
                    <Label className="text-black font-semibold">Delivery Location</Label>
                    <Input
                      type="text"
                      value={formData.deliveryLocation || ""}
                      onChange={(e) => setFormData({ ...formData, deliveryLocation: e.target.value })}
                      className="cinema-card border-gray-600 text-black bg-white placeholder:text-gray-400"
                      placeholder="Enter classroom or meeting location"
                      required
                    />
                  </div>

                  <div>
                    <Label className="text-black font-semibold">Delivery Time</Label>
                    <Select 
                      value={formData.pickupTime} 
                      onValueChange={(value) => setFormData({ ...formData, pickupTime: value })}
                    >
                      <SelectTrigger className="cinema-card border-gray-600 text-black bg-white">
                        <SelectValue placeholder="Select Time" />
                      </SelectTrigger>
                      <SelectContent className="cinema-card border-gray-600 text-black bg-white">
                        <SelectItem value="11:10">11:10 Break</SelectItem>
                        <SelectItem value="12:30">Lunch Time</SelectItem>
                        <SelectItem value="15:30">After School</SelectItem>
                        <SelectItem value="16:00">Staff Session</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </>
              )}

              <div>
                <Label className="text-black font-semibold">Rental Duration</Label>
                <Select 
                  value={formData.rentalDuration.toString()} 
                  onValueChange={(value) => setFormData({ ...formData, rentalDuration: parseInt(value) })}
                >
                  <SelectTrigger className="cinema-card border-gray-600 text-black bg-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="cinema-card border-gray-600 text-black bg-white">
                    <SelectItem value="24">24 Hours</SelectItem>
                    <SelectItem value="48">48 Hours</SelectItem>
                    <SelectItem value="72">72 Hours (Weekend)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="cinema-card p-4 rounded-lg">
                <h4 className="font-semibold text-white mb-2">Booking Summary</h4>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span className="text-white">Rental Fee:</span>
                    <span className="text-cinema-gold">Free</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white">Late Fee (if applicable):</span>
                    <span className="text-cinema-gold">$2.00 per day</span>
                  </div>
                </div>
              </div>

              <div className="flex gap-4 pt-4">
                <Button 
                  type="button" 
                  variant="outline"
                  className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-700"
                  onClick={() => onOpenChange(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  className="flex-1 bg-cinema-red hover:bg-red-700 text-white font-semibold"
                  disabled={createBookingMutation.isPending}
                >
                  {createBookingMutation.isPending ? "Submitting..." : "Submit Booking"}
                </Button>
              </div>
            </form>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
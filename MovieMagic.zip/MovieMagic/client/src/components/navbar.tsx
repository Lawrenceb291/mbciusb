import { Link, useLocation } from "wouter";
import { Film, User } from "lucide-react";
import mbciLogo from "@assets/9E9KqIYe_400x400.jpg";

export default function Navbar() {
  const [location] = useLocation();

  return (
    <nav className="cinema-nav border-b border-slate-blue">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Link href="/">
                <div className="flex items-center cursor-pointer">
                  <img 
                    src={mbciLogo} 
                    alt="MBCI Spartans Logo" 
                    className="h-10 w-10 mr-3 rounded-lg"
                  />
                  <div>
                    <h1 className="text-2xl font-bold mbci-blue">
                      CampusFlix
                    </h1>
                    <p className="text-sm spartan-gold font-semibold -mt-1">MBCI Spartans</p>
                  </div>
                </div>
              </Link>
            </div>
            <div className="hidden md:block ml-10">
              <div className="flex items-baseline space-x-4">
                <Link href="/" className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  location === "/" ? "mbci-blue" : "text-gray-300 hover:text-white"
                }`}>
                  Browse Movies
                </Link>
                <Link href="/admin" className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  location === "/admin" ? "mbci-blue" : "text-gray-300 hover:text-white"
                }`}>
                  Admin Panel
                </Link>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-sm text-gray-300">
              <span>Welcome, Student</span>
            </div>
            <User className="text-2xl text-gray-400" />
          </div>
        </div>
      </div>
    </nav>
  );
}

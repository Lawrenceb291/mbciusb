import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Movie, Booking } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Trash2, Edit, Plus, Search, Film, Users, Calendar, TrendingUp } from "lucide-react";
import AddMovieModal from "@/components/add-movie-modal";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatDate, formatTime, getAvailabilityStatus } from "@/lib/utils";

const AUTHORIZED_ADMIN_EMAILS = [
  "admin@university.edu",
  "librarian@university.edu"
];

export default function Admin() {
  const [addMovieModalOpen, setAddMovieModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedGenre, setSelectedGenre] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [userEmail] = useState("student@university.edu"); // Replace with actual user email from your auth system
  
  const [adminPassword, setAdminPassword] = useState("");
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  if (!AUTHORIZED_ADMIN_EMAILS.includes(userEmail.toLowerCase()) || !isAuthenticated) {
    return (
      <div className="min-h-screen cinema-bg p-6 flex items-center justify-center">
        <Card className="cinema-card w-full max-w-md">
          <CardContent className="pt-6">
            <div className="text-center">
              <h2 className="text-2xl font-bold text-white mb-2">Admin Authentication</h2>
              {!AUTHORIZED_ADMIN_EMAILS.includes(userEmail.toLowerCase()) ? (
                <p className="text-gray-400">You don't have permission to access the admin panel.</p>
              ) : (
                <div className="space-y-4">
                  <p className="text-gray-400">Please enter admin password to continue.</p>
                  <Input
                    type="password"
                    placeholder="Enter admin password"
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                    className="cinema-card border-gray-600"
                  />
                  <Button
                    className="w-full bg-cinema-red hover:bg-red-700"
                    onClick={() => {
                      if (adminPassword === "admin123") { // Match with backend password
                        setIsAuthenticated(true);
                      } else {
                        toast({
                          title: "Authentication Failed",
                          description: "Invalid admin password",
                          variant: "destructive"
                        });
                      }
                    }}
                  >
                    Login
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: movies = [], isLoading: moviesLoading } = useQuery<Movie[]>({
    queryKey: ["/api/movies", searchQuery, selectedGenre, selectedCategory],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (searchQuery) params.append("search", searchQuery);
      if (selectedGenre && selectedGenre !== "All Genres") params.append("genre", selectedGenre);
      if (selectedCategory && selectedCategory !== "All Categories") params.append("category", selectedCategory);
      
      const response = await fetch(`/api/movies?${params}`);
      return response.json();
    },
  });

  const { data: bookings = [] } = useQuery<(Booking & { movie: Movie })[]>({
    queryKey: ["/api/bookings"],
    queryFn: async () => {
      const response = await fetch("/api/bookings");
      return response.json();
    },
  });

  const deleteMovieMutation = useMutation({
    mutationFn: async (movieId: number) => {
      const response = await apiRequest("DELETE", `/api/movies/${movieId}`);
      return response;
    },
    onSuccess: () => {
      toast({
        title: "Movie Deleted",
        description: "The movie has been successfully removed from the catalog.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/movies"] });
    },
    onError: () => {
      toast({
        title: "Failed to Delete Movie",
        description: "There was an error deleting the movie. Please try again.",
        variant: "destructive",
      });
    },
  });

  const returnMovieMutation = useMutation({
    mutationFn: async (bookingId: number) => {
      const response = await apiRequest("POST", `/api/bookings/${bookingId}/return`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Movie Returned",
        description: "The movie has been marked as returned and is now available for rental.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/bookings"] });
      queryClient.invalidateQueries({ queryKey: ["/api/movies"] });
    },
    onError: () => {
      toast({
        title: "Failed to Return Movie",
        description: "There was an error processing the return. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleDeleteMovie = (movieId: number) => {
    if (confirm("Are you sure you want to delete this movie? This action cannot be undone.")) {
      deleteMovieMutation.mutate(movieId);
    }
  };

  const handleReturnMovie = (bookingId: number) => {
    if (confirm("Mark this movie as returned?")) {
      returnMovieMutation.mutate(bookingId);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-500 text-white">Active</Badge>;
      case "upcoming":
        return <Badge className="bg-yellow-500 text-black">Upcoming</Badge>;
      case "returned":
        return <Badge className="bg-gray-600 text-white">Returned</Badge>;
      case "overdue":
        return <Badge className="bg-red-500 text-white">Overdue</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  // Calculate statistics
  const totalMovies = movies.length;
  const totalActiveBookings = bookings.filter(b => b.status === "active" || b.status === "upcoming").length;
  const totalRentals = bookings.length;
  const averageRating = movies.reduce((acc, movie) => acc + parseFloat(movie.rating), 0) / movies.length || 0;

  return (
    <div className="min-h-screen cinema-bg p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Admin Dashboard</h1>
          <p className="text-gray-400">Manage movies, bookings, and view system statistics</p>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="cinema-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">Total Movies</CardTitle>
              <Film className="h-4 w-4 text-gray-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{totalMovies}</div>
              <p className="text-xs text-gray-400">Movies in catalog</p>
            </CardContent>
          </Card>

          <Card className="cinema-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">Active Bookings</CardTitle>
              <Calendar className="h-4 w-4 text-gray-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{totalActiveBookings}</div>
              <p className="text-xs text-gray-400">Currently rented/upcoming</p>
            </CardContent>
          </Card>

          <Card className="cinema-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">Total Rentals</CardTitle>
              <Users className="h-4 w-4 text-gray-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{totalRentals}</div>
              <p className="text-xs text-gray-400">All time bookings</p>
            </CardContent>
          </Card>

          <Card className="cinema-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-300">Avg. Rating</CardTitle>
              <TrendingUp className="h-4 w-4 text-gray-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{averageRating.toFixed(1)}</div>
              <p className="text-xs text-gray-400">Movie catalog rating</p>
            </CardContent>
          </Card>
        </div>

        {/* Movies Management Section */}
        <Card className="cinema-card mb-8">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="text-xl font-bold text-white">Movies Management</CardTitle>
              <Button 
                className="bg-cinema-red hover:bg-red-700 text-white"
                onClick={() => setAddMovieModalOpen(true)}
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Movie
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {/* Search and Filters */}
            <div className="flex flex-col md:flex-row gap-4 mb-6">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  type="text"
                  placeholder="Search movies..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="cinema-card border-gray-600 pl-10 text-white placeholder-gray-400"
                />
              </div>
              <Select value={selectedGenre} onValueChange={setSelectedGenre}>
                <SelectTrigger className="cinema-card border-gray-600 text-white w-40">
                  <SelectValue placeholder="All Genres" />
                </SelectTrigger>
                <SelectContent className="cinema-card border-gray-600">
                  <SelectItem value="all">All Genres</SelectItem>
                  <SelectItem value="Action">Action</SelectItem>
                  <SelectItem value="Comedy">Comedy</SelectItem>
                  <SelectItem value="Drama">Drama</SelectItem>
                  <SelectItem value="Educational">Educational</SelectItem>
                  <SelectItem value="Horror">Horror</SelectItem>
                  <SelectItem value="Sci-Fi">Sci-Fi</SelectItem>
                  <SelectItem value="Documentary">Documentary</SelectItem>
                </SelectContent>
              </Select>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="cinema-card border-gray-600 text-white w-48">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent className="cinema-card border-gray-600">
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="entertainment">Entertainment</SelectItem>
                  <SelectItem value="educational">Educational</SelectItem>
                  <SelectItem value="study-resources">Study Resources</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Movies Table */}
            <div className="rounded-md border border-gray-600">
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-600">
                    <TableHead className="text-gray-300">Title</TableHead>
                    <TableHead className="text-gray-300">Genre</TableHead>
                    <TableHead className="text-gray-300">Category</TableHead>
                    <TableHead className="text-gray-300">Availability</TableHead>
                    <TableHead className="text-gray-300">Rating</TableHead>
                    <TableHead className="text-gray-300">Year</TableHead>
                    <TableHead className="text-gray-300">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {moviesLoading ? (
                    [...Array(5)].map((_, i) => (
                      <TableRow key={i} className="border-gray-600">
                        <TableCell colSpan={7}>
                          <div className="h-4 bg-gray-600 rounded animate-pulse" />
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    movies.map((movie) => {
                      const availability = getAvailabilityStatus(movie.availableCopies);
                      return (
                        <TableRow key={movie.id} className="border-gray-600">
                          <TableCell className="text-white font-medium">{movie.title}</TableCell>
                          <TableCell className="text-gray-300">{movie.genre}</TableCell>
                          <TableCell className="text-gray-300">
                            <Badge variant="outline" className="capitalize border-gray-500 text-gray-300">
                              {movie.category.replace("-", " ")}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge className={availability.color}>
                              {movie.availableCopies}/{movie.totalCopies}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-gray-300">{movie.rating}</TableCell>
                          <TableCell className="text-gray-300">{movie.year}</TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button
                                variant="outline"
                                size="sm"
                                className="border-gray-600 text-gray-300 hover:bg-gray-700"
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                className="border-red-600 text-red-400 hover:bg-red-900"
                                onClick={() => handleDeleteMovie(movie.id)}
                                disabled={deleteMovieMutation.isPending}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Recent Bookings */}
        <Card className="cinema-card">
          <CardHeader>
            <CardTitle className="text-xl font-bold text-white">Recent Bookings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border border-gray-600">
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-600">
                    <TableHead className="text-gray-300">Student</TableHead>
                    <TableHead className="text-gray-300">Movie</TableHead>
                    <TableHead className="text-gray-300">Pickup Code</TableHead>
                    <TableHead className="text-gray-300">Pickup Date</TableHead>
                    <TableHead className="text-gray-300">Locker</TableHead>
                    <TableHead className="text-gray-300">Status</TableHead>
                    <TableHead className="text-gray-300">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {bookings.slice(0, 10).map((booking) => (
                    <TableRow key={booking.id} className="border-gray-600">
                      <TableCell>
                        <div>
                          <div className="text-white font-medium">{booking.studentName}</div>
                          <div className="text-gray-400 text-sm">{booking.studentEmail}</div>
                        </div>
                      </TableCell>
                      <TableCell className="text-white">{booking.movie.title}</TableCell>
                      <TableCell className="text-cinema-gold font-mono font-bold">{booking.pickupCode}</TableCell>
                      <TableCell className="text-gray-300">
                        {formatDate(booking.pickupDate)} at {formatTime(booking.pickupTime)}
                      </TableCell>
                      <TableCell className="text-gray-300">{booking.lockerLocation}</TableCell>
                      <TableCell>{getStatusBadge(booking.status)}</TableCell>
                      <TableCell>
                        {booking.status === "active" && (
                          <Button
                            variant="outline"
                            size="sm"
                            className="border-green-600 text-green-400 hover:bg-green-900"
                            onClick={() => handleReturnMovie(booking.id)}
                            disabled={returnMovieMutation.isPending}
                          >
                            Mark Returned
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>

      <AddMovieModal 
        open={addMovieModalOpen}
        onOpenChange={setAddMovieModalOpen}
      />
    </div>
  );
}

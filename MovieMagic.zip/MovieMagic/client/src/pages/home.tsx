import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Movie, Booking } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Search, Plus, Star, MapPin, Clock, Calendar } from "lucide-react";
import MovieCard from "@/components/movie-card";
import BookingModal from "@/components/booking-modal";
import AddMovieModal from "@/components/add-movie-modal";
import { formatDate, formatTime } from "@/lib/utils";

export default function Home() {
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [bookingModalOpen, setBookingModalOpen] = useState(false);
  const [addMovieModalOpen, setAddMovieModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedGenre, setSelectedGenre] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [studentEmail] = useState("student@university.edu"); // Mock student email

  const { data: movies = [], isLoading: moviesLoading } = useQuery<Movie[]>({
    queryKey: ["/api/movies", searchQuery, selectedGenre, selectedCategory],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (searchQuery) params.append("search", searchQuery);
      if (selectedGenre && selectedGenre !== "All Genres") params.append("genre", selectedGenre);
      if (selectedCategory && selectedCategory !== "All Categories") params.append("category", selectedCategory);
      
      const response = await fetch(`/api/movies?${params}`);
      return response.json();
    },
  });

  const { data: bookings = [] } = useQuery<(Booking & { movie: Movie })[]>({
    queryKey: ["/api/bookings", studentEmail],
    queryFn: async () => {
      const response = await fetch(`/api/bookings?studentEmail=${studentEmail}`);
      return response.json();
    },
  });

  const handleBookMovie = (movie: Movie) => {
    setSelectedMovie(movie);
    setBookingModalOpen(true);
  };

  const featuredMovies = movies.slice(0, 4);
  const allMovies = movies.slice(4);

  const activeBookings = bookings.filter(b => b.status === "active" || b.status === "upcoming");
  const pastBookings = bookings.filter(b => b.status === "returned");

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-500 text-white">Active</Badge>;
      case "upcoming":
        return <Badge className="bg-yellow-500 text-black">Upcoming</Badge>;
      case "returned":
        return <Badge className="bg-gray-600 text-white">Returned</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  return (
    <div className="min-h-screen cinema-bg">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-deep-navy via-dark-purple to-slate-blue py-16">
        <div className="absolute inset-0 bg-cover bg-center opacity-30" 
             style={{backgroundImage: 'url("https://images.unsplash.com/photo-1489599743956-7673b209becc?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=400")'}} />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Your Campus <span className="mbci-blue">Movie Experience</span>
            </h1>
            <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
              Rent movies on USB drives from secure campus lockers. Pick up, watch, and return with ease.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button className="bg-cinema-red hover:bg-red-700 text-white px-8 py-3 font-semibold">
                Browse Movies
              </Button>
              <Button variant="outline" className="border-cinema-red cinema-red hover:bg-cinema-red hover:text-white px-8 py-3 font-semibold">
                View My Rentals
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Search and Filters */}
      <section className="cinema-nav py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="flex-1 max-w-md relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                type="text"
                placeholder="Search movies..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="cinema-card border-gray-600 pl-10 text-white placeholder-gray-400"
              />
            </div>
            <div className="flex gap-4">
              <Select value={selectedGenre} onValueChange={setSelectedGenre}>
                <SelectTrigger className="cinema-card border-gray-600 text-white">
                  <SelectValue placeholder="All Genres" />
                </SelectTrigger>
                <SelectContent className="cinema-card border-gray-600">
                  <SelectItem value="all">All Genres</SelectItem>
                  <SelectItem value="Action">Action</SelectItem>
                  <SelectItem value="Comedy">Comedy</SelectItem>
                  <SelectItem value="Drama">Drama</SelectItem>
                  <SelectItem value="Educational">Educational</SelectItem>
                  <SelectItem value="Horror">Horror</SelectItem>
                  <SelectItem value="Sci-Fi">Sci-Fi</SelectItem>
                  <SelectItem value="Documentary">Documentary</SelectItem>
                  <SelectItem value="Adventure">Adventure</SelectItem>
                  <SelectItem value="Thriller">Thriller</SelectItem>
                </SelectContent>
              </Select>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="cinema-card border-gray-600 text-white">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent className="cinema-card border-gray-600">
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="entertainment">Entertainment</SelectItem>
                  <SelectItem value="educational">Educational</SelectItem>
                  <SelectItem value="study-resources">Study Resources</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Movies */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white mb-8">Featured Movies</h2>
          
          {moviesLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="cinema-card rounded-xl h-96 animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
              {featuredMovies.map((movie) => (
                <MovieCard key={movie.id} movie={movie} onBook={handleBookMovie} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* All Movies Grid */}
      <section className="py-12 cinema-nav">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold text-white">All Movies</h2>
            <Button 
              className="bg-cinema-red hover:bg-red-700 text-white font-semibold"
              onClick={() => setAddMovieModalOpen(true)}
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Movie
            </Button>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 xl:grid-cols-6 gap-4">
            {allMovies.map((movie) => (
              <MovieCard key={movie.id} movie={movie} onBook={handleBookMovie} size="small" />
            ))}
          </div>
        </div>
      </section>

      {/* My Bookings Section */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white mb-8">My Bookings</h2>
          
          {activeBookings.length === 0 && pastBookings.length === 0 ? (
            <Card className="cinema-card p-8 text-center">
              <CardContent>
                <p className="text-gray-400 text-lg">No bookings found. Start browsing movies to make your first booking!</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Active/Upcoming Bookings */}
              {activeBookings.map((booking) => (
                <Card key={booking.id} className={`cinema-card p-6 border-l-4 ${
                  booking.status === "active" ? "border-cinema-red" : "border-cinema-gold"
                }`}>
                  <CardContent className="p-0">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-semibold text-white">{booking.movie.title}</h3>
                        <p className="text-gray-400">{booking.movie.genre} • {booking.movie.duration}</p>
                      </div>
                      {getStatusBadge(booking.status)}
                    </div>
                    
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-400">Pickup Code:</span>
                        <span className="cinema-gold font-mono font-bold">{booking.pickupCode}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Locker:</span>
                        <span className="text-white">{booking.lockerLocation}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">
                          {booking.status === "upcoming" ? "Pickup:" : "Due:"}
                        </span>
                        <span className="text-white">
                          {formatDate(booking.pickupDate)} at {formatTime(booking.pickupTime)}
                        </span>
                      </div>
                      
                      {booking.status === "active" && (
                        <div className="mt-4 pt-4 border-t border-gray-600">
                          <img 
                            src="https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=100" 
                            alt="USB device" 
                            className="w-16 h-10 object-cover rounded-md mx-auto" 
                          />
                        </div>
                      )}
                    </div>
                    
                    <div className="mt-6 flex gap-3">
                      <Button className="flex-1 bg-cinema-red hover:bg-red-700 text-white font-semibold">
                        {booking.status === "upcoming" ? "Modify Booking" : "Extend Rental"}
                      </Button>
                      <Button variant="outline" className="px-4 border-gray-600 text-gray-300 hover:bg-gray-700">
                        <MapPin className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}

              {/* Past Bookings */}
              {pastBookings.slice(0, 2).map((booking) => (
                <Card key={booking.id} className="cinema-card p-6 border-l-4 border-gray-600">
                  <CardContent className="p-0">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-semibold text-white">{booking.movie.title}</h3>
                        <p className="text-gray-400">{booking.movie.genre} • {booking.movie.duration}</p>
                      </div>
                      {getStatusBadge(booking.status)}
                    </div>
                    
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-400">Rented:</span>
                        <span className="text-white">{formatDate(booking.pickupDate)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Returned:</span>
                        <span className="text-white">{booking.returnedAt ? formatDate(booking.returnedAt.toString()) : "N/A"}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Rating:</span>
                        <div className="cinema-gold flex">
                          {[...Array(4)].map((_, i) => (
                            <Star key={i} className="w-4 h-4 fill-current" />
                          ))}
                          <Star className="w-4 h-4" />
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-6">
                      <Button 
                        variant="outline" 
                        className="w-full border-cinema-red cinema-red hover:bg-cinema-red hover:text-white font-semibold"
                        onClick={() => handleBookMovie(booking.movie)}
                      >
                        Rent Again
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 bg-gradient-to-b from-dark-purple to-deep-navy">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-white mb-4">How It Works</h2>
            <p className="text-gray-300 max-w-2xl mx-auto">Get your favorite movies in just three simple steps</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-cinema-red w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="text-white text-2xl" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">1. Browse & Book</h3>
              <p className="text-gray-400">Search our movie catalog and book your preferred film with your desired pickup time and location.</p>
            </div>
            
            <div className="text-center">
              <div className="bg-cinema-red w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="text-white text-2xl" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">2. Get Your Code</h3>
              <p className="text-gray-400">Receive a unique pickup code and locker location. Head to the designated campus locker at your scheduled time.</p>
            </div>
            
            <div className="text-center">
              <div className="bg-cinema-red w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="text-white text-2xl" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">3. Watch & Return</h3>
              <p className="text-gray-400">Enjoy your movie and return the USB drive to any campus locker before the due date.</p>
            </div>
          </div>

          <div className="mt-12 text-center">
            <img 
              src="https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=400" 
              alt="Students watching movie together" 
              className="rounded-xl shadow-lg mx-auto max-w-4xl w-full object-cover" 
            />
          </div>
        </div>
      </section>

      <BookingModal 
        movie={selectedMovie}
        open={bookingModalOpen}
        onOpenChange={setBookingModalOpen}
      />

      <AddMovieModal 
        open={addMovieModalOpen}
        onOpenChange={setAddMovieModalOpen}
      />
    </div>
  );
}
